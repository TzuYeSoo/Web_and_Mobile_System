public class getUserinfo {

    private static getUserinfo _instance;

    public static getUserinfo get_instance() {
        if (_instance == null) {
            _instance = new getUserinfo();
        }
        return _instance;
    }

    private String user_id, full_name;

    public void set_user_id(String user_id) {
        this.user_id = user_id;
    }

    public String get_user_id() {
        return user_id;
    }

    public void set_full_name(String full_name) {
        this.full_name = full_name;
    }

    public String get_full_name() {
        return full_name;
    }
}
