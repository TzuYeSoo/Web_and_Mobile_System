package com.example.mobile_app_reservation;

import android.content.Context;
import android.content.Intent;
import android.media.Image;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.GridLayout;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.ArrayList;

public class clothes extends AppCompatActivity {

    String[] items = {"asdad", "asdadsd"};
    ArrayAdapter<String> arrayAdapter;

    AutoCompleteTextView option_program;
    AutoCompleteTextView option_size;
    int itemcount;
    AutoCompleteTextView option_type;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_clothes);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        ImageButton cart = findViewById(R.id.btn_cart);
        Context context = this;
        option_program = findViewById(R.id.option_program);
        option_type = findViewById(R.id.option_type);
        option_size = findViewById(R.id.option_size);
        nav_bar_logic.getInstance().change_activity(this);

        arrayAdapter = new ArrayAdapter<String>(this, R.layout.list_item, items);

        option_program.setAdapter(arrayAdapter);
        option_type.setAdapter(arrayAdapter);
        option_size.setAdapter(arrayAdapter);


        GridLayout gridLayout = findViewById(R.id.grid_layout);
        UniformImage.get_instance().getUniform(gridLayout, this);

        option_size.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                itemcount = 20;

            }
        });
        option_type.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                itemcount = 3;

            }
        });

        option_program.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                itemcount = 7;

            }
        });

        cart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
               Intent intent = new Intent(context, Cart.class);
               startActivity(intent);
            }
        });
    }
}