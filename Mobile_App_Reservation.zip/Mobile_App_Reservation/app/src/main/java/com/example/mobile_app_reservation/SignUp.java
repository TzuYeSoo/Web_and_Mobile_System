package com.example.mobile_app_reservation;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.android.volley.Request;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class SignUp extends AppCompatActivity {

    private EditText txt_first_name, txt_last_name, txt_add_username, txt_add_password;
    private TextView btn_sign;

    private final String SIGNUP_URL = "http://192.168.0.112/finalproject3/android_query_insert_user.php"; // change IP as needed

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_sign_up);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        txt_first_name = findViewById(R.id.txt_first_name);
        txt_last_name = findViewById(R.id.txt_last_name);
        txt_add_username = findViewById(R.id.txt_add_username);
        txt_add_password = findViewById(R.id.txt_add_password);
        btn_sign = findViewById(R.id.btn_sign);

        btn_sign.setOnClickListener(v -> {
            String fname = txt_first_name.getText().toString().trim();
            String lname = txt_last_name.getText().toString().trim();
            String user = txt_add_username.getText().toString().trim();
            String pass = txt_add_password.getText().toString().trim();

            if (fname.isEmpty() || lname.isEmpty() || user.isEmpty() || pass.isEmpty()) {
                Toast.makeText(SignUp.this, "All fields are required", Toast.LENGTH_SHORT).show();
            } else {
                registerUser(fname, lname, user, pass);
            }
        });
    }

    private void registerUser(String firstName, String lastName, String username, String password) {
        StringRequest request = new StringRequest(Request.Method.POST, SIGNUP_URL,
                response -> {
                    try {
                        Log.d("VolleySignup", "Raw response: " + response);
                        JSONObject jsonObject = new JSONObject(response);
                        String status = jsonObject.getString("status");
                        String message = jsonObject.getString("message");
                        Toast.makeText(SignUp.this, message, Toast.LENGTH_LONG).show();
                        if (status.equals("success")) {
                            Intent intent = new Intent(SignUp.this, MainActivity.class);
                            startActivity(intent);
                            finish(); // Optional: prevent user from going back to sign up
                        }


                    } catch (JSONException e) {
                        e.printStackTrace();
                        Toast.makeText(SignUp.this, "Response error", Toast.LENGTH_SHORT).show();
                    }
                },
                error -> Toast.makeText(SignUp.this, "Volley error: " + error.getMessage(), Toast.LENGTH_SHORT).show()
        ) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<>();
                params.put("firt_name", firstName);
                params.put("last_name", lastName);
                params.put("username", username);
                params.put("user_password", password);
                return params;
            }
        };

        Volley.newRequestQueue(this).add(request);
    }
}
