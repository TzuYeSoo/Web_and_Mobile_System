package com.example.mobile_app_reservation;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.util.Base64;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.GridLayout;
import android.widget.ImageView;
import android.widget.TextView;

import com.android.volley.Request;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;

public class UniformImage {
    private static UniformImage _instance;

    public static UniformImage get_instance() {
        if (_instance == null) {
            _instance = new UniformImage();
        }
        return _instance;
    }

    public void getUniform(GridLayout grid, Context context) {
        LayoutInflater inflater = LayoutInflater.from(context);
        String url = "http://192.168.0.112/finalproject3/android_query_uniform.php";

        StringRequest request = new StringRequest(Request.Method.GET, url,
                response -> {
                    Log.d("UniformDebug", "Response: " + response);
                    try {
                        JSONArray array = new JSONArray(response);
                        for (int i = 0; i < array.length(); i++) {
                            JSONObject obj = array.getJSONObject(i);
                            String imageBase64 = obj.optString("image");
                            String label = obj.optString("label");
                            String price = obj.optString("price");
                            String quantity = obj.optString("quantity");
                            String part = obj.optString("part");
                            String size = obj.optString("size");
                            String id = obj.optString("id");

                            View itemView = inflater.inflate(R.layout.reusable_clothes_image, grid, false);
                            ImageView imageView = itemView.findViewById(R.id.img_items);
                            TextView textView = itemView.findViewById(R.id.txt_itemname);

                            Bitmap bitmap = null;
                            String imagePath = null;

                            if (imageBase64 != null && imageBase64.contains(",")) {
                                try {
                                    String base64Data = imageBase64.split(",")[1];
                                    byte[] decodedBytes = Base64.decode(base64Data, Base64.DEFAULT);
                                    bitmap = BitmapFactory.decodeByteArray(decodedBytes, 0, decodedBytes.length);
                                    imageView.setImageBitmap(bitmap);

                                    imagePath = saveBitmapToCache(context, bitmap, "uniform_" + id + ".png");
                                } catch (Exception e) {
                                    e.printStackTrace();
                                    imageView.setImageResource(R.drawable.ic_launcher_background);
                                }
                            } else {
                                imageView.setImageResource(R.drawable.ic_launcher_background);
                            }

                            textView.setText(label + "\nPRICE: " + price);

                            String finalImagePath = imagePath; // for use inside lambda
                            imageView.setOnClickListener(v -> {
                                Intent intent = new Intent(context, uniform_detail.class);
                                intent.putExtra("imagePath", finalImagePath);
                                intent.putExtra("label", label);
                                intent.putExtra("price", price);
                                intent.putExtra("quantity", quantity);
                                intent.putExtra("part", part);
                                intent.putExtra("size", size);
                                intent.putExtra("id", id);
                                context.startActivity(intent);
                            });

                            grid.addView(itemView);
                        }
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                },
                Throwable::printStackTrace
        );

        Volley.newRequestQueue(context).add(request);
    }

    private String saveBitmapToCache(Context context, Bitmap bitmap, String filename) {
        File file = new File(context.getCacheDir(), filename);
        try (FileOutputStream fos = new FileOutputStream(file)) {
            bitmap.compress(Bitmap.CompressFormat.PNG, 100, fos);
            return file.getAbsolutePath();
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
}
