package com.example.mobile_app_reservation;

import android.graphics.Bitmap;

public class CartItem {
    private Bitmap image;
    private String name;
    private String price;
    private int quantity;
    private String part;
    private String size;
    private String pickUpDate;

    public CartItem(Bitmap image, String name, String price, int quantity, String part, String size, String pickUpDate) {
        this.image = image;
        this.name = name;
        this.price = price;
        this.quantity = quantity;
        this.part = part;
        this.size = size;
        this.pickUpDate = pickUpDate;
    }

    public Bitmap getImage() { return image; }
    public String getName() { return name; }
    public String getPrice() { return price; }
    public int getQuantity() { return quantity; }
    public String getPart() { return part; }
    public String getSize() { return size; }
    public String getPickUpDate() { return pickUpDate; }
}

