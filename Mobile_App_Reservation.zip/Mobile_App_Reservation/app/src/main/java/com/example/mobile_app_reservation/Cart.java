package com.example.mobile_app_reservation;

import android.graphics.drawable.BitmapDrawable;
import android.widget.ImageView;
import android.widget.TextView;
import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.LinearLayout;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.List;

public class Cart extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_cart);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        LinearLayout layout = findViewById(R.id.cart_layout_content);
        Context context = this;
        nav_bar_logic.getInstance().change_activity(this);

        List<CartItem> cart = getCart.getInstance().getItems(); // Use GetCart (renamed from getCart)
        if (!cart.isEmpty()) {
            for (CartItem item : cart) {
                View itemView = LayoutInflater.from(context).inflate(R.layout.reusable_cart_items, layout, false);

                // Set image
                ImageView imageView = itemView.findViewById(R.id.cart_image_item);
                imageView.setImageBitmap(item.getImage());

                // Set name
                TextView name = itemView.findViewById(R.id.cart_item_name);
                name.setText(item.getName());

                // Set price
                TextView price = itemView.findViewById(R.id.cart_price);
                price.setText("₱" + item.getPrice());

                int newquan = item.getQuantity();
                // Set quantity
                TextView quantity = itemView.findViewById(R.id.cart_quantity);
                quantity.setText("" + newquan);

                // Set size
                TextView size = itemView.findViewById(R.id.cart_item_size);
                size.setText("Size: " + item.getSize());

                // Set part
                TextView part = itemView.findViewById(R.id.cart_item_part);
                part.setText("Part: " + item.getPart());

                // Set pickup date
                TextView date = itemView.findViewById(R.id.cart_item_pickup_date);
                date.setText("Pickup: " + item.getPickUpDate());

                // Add to the layout
                layout.addView(itemView);
            }
        }
    }
}