package com.example.mobile_app_reservation;

public class ReservationItem {
    private String itemName, totalPrice, quantity, pickupDate, price, orderStatus;

    public ReservationItem(String itemName, String totalPrice, String quantity, String pickupDate, String price, String orderStatus) {
        this.itemName = itemName;
        this.totalPrice = totalPrice;
        this.quantity = quantity;
        this.pickupDate = pickupDate;
        this.price = price;
        this.orderStatus = orderStatus;
    }

    public String getItemName() { return itemName; }
    public String getTotalPrice() { return totalPrice; }
    public String getQuantity() { return quantity; }
    public String getPickupDate() { return pickupDate; }
    public String getPrice() { return price; }
    public String getOrderStatus() { return orderStatus; }
}
