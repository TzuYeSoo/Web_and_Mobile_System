package com.example.mobile_app_reservation;

import android.content.Context;
import android.util.Log;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class InsertReservation {

    public interface ReservationCallback {
        void onSuccess(String message);
        void onError(String error);
    }

    public static void sendReservation(
            Context context,
            String userId,
            String uniformId,
            String studentName,
            String orderQuantity,
            String orderTotalPrice,
            String pickupDate,
            ReservationCallback callback
    ) {
        String url = "http://192.168.0.112/finalproject3/android_query_reservation.php"; // Your PHP backend

        Log.d("InsertReservation", "sendReservation called with: " +
                "userId=" + userId + ", uniformId=" + uniformId + ", studentName=" + studentName +
                ", orderQuantity=" + orderQuantity + ", orderTotalPrice=" + orderTotalPrice + ", pickupDate=" + pickupDate);

        StringRequest stringRequest = new StringRequest(Request.Method.POST, url,
                response -> {
                    Log.d("VOLLEY_RESPONSE", response);
                    try {
                        JSONObject jsonObject = new JSONObject(response);
                        if (jsonObject.getString("status").equals("success")) {
                            callback.onSuccess(jsonObject.getString("message"));
                        } else {
                            callback.onError(jsonObject.getString("message"));
                        }
                    } catch (JSONException e) {
                        callback.onError("Parsing error: " + e.getMessage());
                    }
                },
                error -> {
                    String message;
                    if (error.networkResponse != null && error.networkResponse.data != null) {
                        message = new String(error.networkResponse.data);
                        Toast.makeText(context, "Server response error: " + message, Toast.LENGTH_LONG).show();
                    } else {
                        message = "Network error: " + error.toString();
                        Toast.makeText(context, message, Toast.LENGTH_LONG).show();
                    }
                    Log.e("ReservationError", message);
                    callback.onError(message);
                }
        ) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<>();

                // Safely add parameters, log null or empty values
                if (userId == null || userId.isEmpty()) Log.w("InsertReservation", "userId is null or empty");
                if (uniformId == null || uniformId.isEmpty()) Log.w("InsertReservation", "uniformId is null or empty");
                if (studentName == null || studentName.isEmpty()) Log.w("InsertReservation", "studentName is null or empty");
                if (orderQuantity == null || orderQuantity.isEmpty()) Log.w("InsertReservation", "orderQuantity is null or empty");
                if (orderTotalPrice == null || orderTotalPrice.isEmpty()) Log.w("InsertReservation", "orderTotalPrice is null or empty");
                if (pickupDate == null || pickupDate.isEmpty()) Log.w("InsertReservation", "pickupDate is null or empty");

                params.put("user_id", userId != null ? userId : "");
                params.put("uniform_id", uniformId != null ? uniformId : "");
                params.put("student_name", studentName != null ? studentName : "");
                params.put("order_quantity", orderQuantity != null ? orderQuantity : "");
                params.put("order_total_price", orderTotalPrice != null ? orderTotalPrice : "");
                params.put("pickup_date", pickupDate != null ? pickupDate : "");

                Log.d("POST_PARAMS", params.toString());
                return params;
            }

            @Override
            public String getBodyContentType() {
                return "application/x-www-form-urlencoded; charset=UTF-8";
            }
        };

        RequestQueue queue = Volley.newRequestQueue(context);
        queue.add(stringRequest);
    }
}