package com.example.mobile_app_reservation;

import java.util.ArrayList;
import java.util.List;

public class getCart {
    private static getCart _instance;
    private List<CartItem> cartItems;

    private getCart() {
        cartItems = new ArrayList<>();
    }

    public static getCart getInstance() {
        if (_instance == null) {
            _instance = new getCart();
        }
        return _instance;
    }

    public void addItem(CartItem item) {
        cartItems.add(item);
    }

    public List<CartItem> getItems() {
        return cartItems;
    }

    public void clearCart() {
        cartItems.clear();
    }
}
