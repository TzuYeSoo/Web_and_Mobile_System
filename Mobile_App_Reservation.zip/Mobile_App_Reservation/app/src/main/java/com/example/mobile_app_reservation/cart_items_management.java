package com.example.mobile_app_reservation;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;

public class cart_items_management {

    private static cart_items_management _instance;

    public static cart_items_management getInstance(){

        if(_instance == null){
            _instance = new cart_items_management();
        }

        return _instance;
    }
    ImageButton add, minus;
    TextView item_count;
    @SuppressLint("MissingInflatedId")
    int itemcount;
    public void getCartItems(LinearLayout container, Context context) {
        LayoutInflater inflater = LayoutInflater.from(context);

        for (int i = 0; i < 5; i++) {
            itemcount = i;
            View itemView = inflater.inflate(
                    R.layout.reusable_cart_items,
                    container,
                    false
            );

            ImageButton btnAdd   = itemView.findViewById(R.id.btn_add);
            ImageButton btnMinus = itemView.findViewById(R.id.btn_minus);
            TextView tvCount  = itemView.findViewById(R.id.cart_quantity);

            final int[] count = { 1 };
            tvCount.setText(String.valueOf(count[0]));

            btnAdd.setOnClickListener(v -> {
                count[0]++;
                tvCount.setText(String.valueOf(count[0]));
            });
            btnMinus.setOnClickListener(v -> {
                if (count[0] > 1) {
                    count[0]--;
                    tvCount.setText(String.valueOf(count[0]));
                }
            });



            ImageButton btnDelete = itemView.findViewById(R.id.btn_remove_item);

            btnDelete.setOnClickListener(v -> {
                new AlertDialog.Builder(context)
                        .setTitle("REMOVE ITEM")
                        .setMessage("Are you sure to remove the item")
                        .setPositiveButton("Yes", (dialog, which) ->{
                            itemView.animate()
                                    .alpha(0f)
                                    .setDuration(300)
                                    .withEndAction(() -> container.removeView(itemView));
                        })
                        .setNegativeButton("No", null)
                        .show();

            });

            container.addView(itemView);
        }
    }

}