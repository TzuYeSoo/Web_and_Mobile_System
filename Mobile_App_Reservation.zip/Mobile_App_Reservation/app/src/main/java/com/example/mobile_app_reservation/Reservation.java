package com.example.mobile_app_reservation;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.Request;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Reservation extends AppCompatActivity {

    private RecyclerView recyclerView;
    private ReservationAdapter adapter;
    private List<ReservationItem> reservationList;
    private String userId = GET_USER_CREDENTIAL.getInstance().get_user_id(); // Replace with dynamic user ID if available
    private String URL = "http://192.168.0.112/finalproject3/android_query_reservation_list.php";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_reservation);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        nav_bar_logic.getInstance().change_activity(this);
        Context context = this;
        ImageButton notif = findViewById(R.id.btn_notification);
        notif.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(context, Notification.class);
                startActivity(intent);
            }
        });

        LinearLayout reservationContainer = findViewById(R.id.reservation_container);
        reservationList = new ArrayList<>();
        TextView fullname = findViewById(R.id.txt_user);
        fullname.setText(GET_USER_CREDENTIAL.getInstance().getfullname());
        StringRequest request = new StringRequest(Request.Method.POST, URL,
                response -> {
                    try {
                        JSONObject jsonObject = new JSONObject(response);
                        if (jsonObject.getString("status").equals("success")) {
                            JSONArray array = jsonObject.getJSONArray("reservations");

                            for (int i = 0; i < array.length(); i++) {
                                JSONObject obj = array.getJSONObject(i);
                                ReservationItem item = new ReservationItem(
                                        obj.getString("itemname"),
                                        obj.getString("totalprice"),
                                        obj.getString("quantity"),
                                        obj.getString("pickupdate"),
                                        obj.getString("price"),
                                        obj.getString("order_status") // 👈 Include this
                                );
                                reservationList.add(item);

                                // Inflate and populate each card
                                View cardView = getLayoutInflater().inflate(R.layout.item_reservation_card, reservationContainer, false);
                                ((TextView) cardView.findViewById(R.id.item_name)).setText(item.getItemName());
                                ((TextView) cardView.findViewById(R.id.total_price)).setText("Total Price: " + item.getTotalPrice());
                                ((TextView) cardView.findViewById(R.id.item_quantity)).setText("Quantity: " + item.getQuantity());
                                ((TextView) cardView.findViewById(R.id.reserve_date)).setText("Pickup: " + item.getPickupDate());
                                ((TextView) cardView.findViewById(R.id.item_price)).setText("Price per Item: " + item.getPrice());
                                ((TextView) cardView.findViewById(R.id.status)).setText("Status: " + item.getOrderStatus());

                                reservationContainer.addView(cardView);
                            }
                        } else {
                            Toast.makeText(context, jsonObject.getString("message"), Toast.LENGTH_SHORT).show();
                        }
                    } catch (JSONException e) {
                        Toast.makeText(context, "Parse error: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                },
                error -> Toast.makeText(context, "Volley error: " + error.getMessage(), Toast.LENGTH_SHORT).show()
        ) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<>();
                params.put("user_id", userId);
                return params;
            }
        };

        Volley.newRequestQueue(context).add(request);


    }
}