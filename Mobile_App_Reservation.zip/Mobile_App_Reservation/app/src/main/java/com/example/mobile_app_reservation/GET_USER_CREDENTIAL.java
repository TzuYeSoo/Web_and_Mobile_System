package com.example.mobile_app_reservation;

public class GET_USER_CREDENTIAL {
    private static GET_USER_CREDENTIAL instance;
    private String user_id, fullname;

    private GET_USER_CREDENTIAL() {}

    public static GET_USER_CREDENTIAL getInstance() {
        if (instance == null) {
            instance = new GET_USER_CREDENTIAL();
        }
        return instance;
    }

    public void set_user_id(String id) {
        this.user_id = id;
    }

    public String get_user_id() {
        return this.user_id;
    }

    public void setfullname(String name) {
        this.fullname = name;
    }

    public String getfullname() {
        return this.fullname;
    }
}


