package com.example.mobile_app_reservation;

import android.content.Context;
import android.widget.Toast;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import org.json.JSONException;
import org.json.JSONObject;
import java.util.HashMap;
import java.util.Map;

public class Login_query {

    public interface LoginCallback {
        void onSuccess(String firstName, String lastName, String userId);
        void onError(String message);
    }

    public static void loginUser(Context context, String username, String password, LoginCallback callback) {
        String url = "http://192.168.0.112/finalproject3/android_query_login.php";

        StringRequest stringRequest = new StringRequest(Request.Method.POST, url,
                response -> {
                    try {
                        JSONObject jsonObject = new JSONObject(response);
                        if (jsonObject.getString("status").equals("success")) {
                            String fname = jsonObject.getString("first_name");
                            String lname = jsonObject.getString("last_name");
                            String id = jsonObject.getString("user_id");

                            callback.onSuccess(fname, lname, id);
                        } else {
                            callback.onError(jsonObject.getString("message"));
                        }
                    } catch (JSONException e) {
                        callback.onError("JSON error: " + e.getMessage());
                    }
                },
                error -> {
                    callback.onError("Volley error: " + error.toString());
                }
        ) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<>();
                params.put("username", username);
                params.put("password", password);
                return params;
            }
        };

        RequestQueue requestQueue = Volley.newRequestQueue(context);
        requestQueue.add(stringRequest);
    }
}

