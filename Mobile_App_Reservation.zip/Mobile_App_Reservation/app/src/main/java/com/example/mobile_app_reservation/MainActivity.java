package com.example.mobile_app_reservation;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        TextView btn_next = findViewById(R.id.btn_next);
        TextView btn_signup = findViewById(R.id.btn_signUp);
        TextView usernameInput = findViewById(R.id.txt_student_num);
        TextView passwordInput = findViewById(R.id.txt_student_pass);
        Context conext = this;

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });


        btn_next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String username = usernameInput.getText().toString().trim();
                String password = passwordInput.getText().toString().trim();

                Login_query.loginUser(conext, username, password, new Login_query.LoginCallback() {
                    @Override
                    public void onSuccess(String firstName, String lastName, String  user_id) {
                        Toast.makeText(MainActivity.this, "Welcome " + firstName + " " + lastName, Toast.LENGTH_LONG).show();
                        GET_USER_CREDENTIAL.getInstance().setfullname(firstName + " " + lastName);
                        GET_USER_CREDENTIAL.getInstance().set_user_id(user_id);
                        Intent intent = new Intent(MainActivity.this, homepage.class);
                        startActivity(intent);
                        finish();
                    }

                    @Override
                    public void onError(String message) {
                        Toast.makeText(MainActivity.this, "Login failed: " + message, Toast.LENGTH_SHORT).show();
                    }
                });
            }
        });

        btn_signup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent= new Intent(MainActivity.this, SignUp.class);
                startActivity(intent);
            }
        });
    }
}