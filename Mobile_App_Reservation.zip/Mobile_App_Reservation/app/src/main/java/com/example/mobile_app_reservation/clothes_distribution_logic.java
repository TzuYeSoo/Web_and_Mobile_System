package com.example.mobile_app_reservation;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;

import com.google.android.material.bottomsheet.BottomSheetBehavior;
import com.google.android.material.bottomsheet.BottomSheetDialog;

import org.w3c.dom.Text;

public class clothes_distribution_logic {

    private static clothes_distribution_logic _instance;

    public static clothes_distribution_logic get_classClothes() {
        if (_instance == null) {
            _instance = new clothes_distribution_logic();
        }
        return _instance;
    }

    public void setClothesItems(TableLayout tbl_clothes_layout, Context context, int itemcount) {
        TableRow tableRow = null;

        for (int i = 0; i < itemcount; i++) {
            if (i % 3 == 0) {
                tableRow = new TableRow(context);
            }
            BottomSheetDialog dialog = new BottomSheetDialog(context);
            View itemView = LayoutInflater.from(context).inflate(R.layout.reusable_clothes_image, null);
            View bottomsheet = LayoutInflater.from(context).inflate(R.layout.clothes_bottomsheet, null);
            ImageButton img_clothes = itemView.findViewById(R.id.img_items);
            TextView txt_itemname = itemView.findViewById(R.id.txt_itemname);
            txt_itemname.setText("Jessie Pogi " + (i + 1));
            img_clothes.setOnClickListener(view -> {
                dialog.setContentView(bottomsheet);
                dialog.show();

                TextView txt_itemName = bottomsheet.findViewById(R.id.item_text);
                ImageView txt_itemImage = bottomsheet.findViewById(R.id.item_image);

                txt_itemName.setText(txt_itemname.getText());
                txt_itemName.setTextSize(20);
            });
            tableRow.addView(itemView);

            if ((i % 3 == 2)) {
                tbl_clothes_layout.addView(tableRow);
            }
        }
    }
}
