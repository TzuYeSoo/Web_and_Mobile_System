package com.example.mobile_app_reservation;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class ReservationAdapter extends RecyclerView.Adapter<ReservationAdapter.ReservationViewHolder> {
    private List<ReservationItem> reservationList;
    private Context context;

    public ReservationAdapter(List<ReservationItem> reservationList, Context context) {
        this.reservationList = reservationList;
        this.context = context;
    }

    @NonNull
    @Override
    public ReservationViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_reservation_card, parent, false);
        return new ReservationViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ReservationViewHolder holder, int position) {
        ReservationItem item = reservationList.get(position);
        holder.itemName.setText(item.getItemName());
        holder.totalPrice.setText("Total Price: " + item.getTotalPrice());
        holder.quantity.setText("Quantity: " + item.getQuantity());
        holder.pickupDate.setText("Pickup: " + item.getPickupDate());
        holder.price.setText("Price per Item: " + item.getPrice());

        holder.itemView.setOnClickListener(v -> {
            Toast.makeText(context, "Clicked: " + item.getItemName(), Toast.LENGTH_SHORT).show();
            // You can add intent here if you want to navigate
        });
    }

    @Override
    public int getItemCount() {
        return reservationList.size();
    }

    public static class ReservationViewHolder extends RecyclerView.ViewHolder {
        TextView itemName, totalPrice, quantity, pickupDate, price;

        public ReservationViewHolder(@NonNull View itemView) {
            super(itemView);
            itemName = itemView.findViewById(R.id.item_name);
            totalPrice = itemView.findViewById(R.id.total_price);
            quantity = itemView.findViewById(R.id.item_quantity);
            pickupDate = itemView.findViewById(R.id.reserve_date);
            price = itemView.findViewById(R.id.item_price);
        }
    }
}
