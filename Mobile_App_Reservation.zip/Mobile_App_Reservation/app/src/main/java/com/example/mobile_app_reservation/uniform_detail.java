package com.example.mobile_app_reservation;

import android.annotation.SuppressLint;
import android.app.DatePickerDialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.io.File;
import java.util.Calendar;

public class uniform_detail extends AppCompatActivity {

    private ImageView imageView;
    private TextView txtLabel, txtPrice, txtQuantity, txtPart, txtSize, totalPrice;

    @SuppressLint("SetTextI18n")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_uniform_detail);
        View rootView = findViewById(R.id.root_layout);
        ViewCompat.setOnApplyWindowInsetsListener(rootView, (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        Context context = this;

        imageView = findViewById(R.id.uniformImage);
        txtLabel = findViewById(R.id.uniformName);
        txtPrice = findViewById(R.id.uniformPrice);
        txtQuantity = findViewById(R.id.quantityText);
        txtPart = findViewById(R.id.uniformDescription);
        txtSize = findViewById(R.id.size);
        totalPrice = findViewById(R.id.totalPrice);

        ImageButton btnBack = findViewById(R.id.back_button);
        btnBack.setOnClickListener(v -> finish());

        Button add = findViewById(R.id.btnIncrease);
        Button decrease = findViewById(R.id.btnDecrease);
        TextView pickUpDate = findViewById(R.id.pickUpDate);

        Intent intent = getIntent();
        String imagePath = intent.getStringExtra("imagePath");
        String label = intent.getStringExtra("label");
        String priceStr = intent.getStringExtra("price");
        String quantityStr = intent.getStringExtra("quantity");
        String part = intent.getStringExtra("part");
        String size = intent.getStringExtra("size");
        String id = intent.getStringExtra("id");

        if (imagePath != null && new File(imagePath).exists()) {
            Bitmap bitmap = BitmapFactory.decodeFile(imagePath);
            if (bitmap != null) {
                imageView.setImageBitmap(bitmap);
            } else {
                imageView.setImageResource(R.drawable.ic_launcher_background);
            }
        } else {
            imageView.setImageResource(R.drawable.ic_launcher_background);
        }

        txtLabel.setText(label);
        txtPart.setText("Part: " + part);
        txtSize.setText("Sizes: " + size);
        txtPrice.setText(priceStr);
        txtQuantity.setText("1");
        totalPrice.setText(priceStr);

        pickUpDate.setOnClickListener(v -> {
            final Calendar calendar = Calendar.getInstance();
            int year = calendar.get(Calendar.YEAR);
            int month = calendar.get(Calendar.MONTH);
            int day = calendar.get(Calendar.DAY_OF_MONTH);

            DatePickerDialog datePickerDialog = new DatePickerDialog(
                    uniform_detail.this,
                    (view, selectedYear, selectedMonth, selectedDay) -> {
                        String date = selectedYear + "-" + (selectedMonth + 1) + "-" + selectedDay;
                        pickUpDate.setText(date);
                    },
                    year, month, day
            );

            datePickerDialog.show();
        });

        int maxQuantity = Integer.parseInt(quantityStr);
        add.setOnClickListener(v -> {
            int currentQuantity = Integer.parseInt(txtQuantity.getText().toString());
            if (currentQuantity < maxQuantity) {
                int newQuantity = currentQuantity + 1;
                txtQuantity.setText(String.valueOf(newQuantity));
                updateTotalPrice(priceStr, newQuantity);
            } else {
                Toast.makeText(context, "Maximum quantity reached", Toast.LENGTH_SHORT).show();
            }
        });

        decrease.setOnClickListener(v -> {
            int currentQuantity = Integer.parseInt(txtQuantity.getText().toString());
            if (currentQuantity > 1) {
                int newQuantity = currentQuantity - 1;
                txtQuantity.setText(String.valueOf(newQuantity));
                updateTotalPrice(priceStr, newQuantity);
            } else {
                Toast.makeText(context, "Quantity cannot be less than 1", Toast.LENGTH_SHORT).show();
            }
        });

        Button add_cart = findViewById(R.id.addtocart);
        add_cart.setOnClickListener(v -> {
            String selectedQuantity = txtQuantity.getText().toString();
            String date = pickUpDate.getText().toString();

            if (date.isEmpty() || date.equals("Select date")) {
                Toast.makeText(context, "Please select a pick-up date", Toast.LENGTH_SHORT).show();
                return;
            }

            String userId = GET_USER_CREDENTIAL.getInstance().get_user_id();
            String studentName = GET_USER_CREDENTIAL.getInstance().getfullname();

            InsertReservation.sendReservation(
                    context,
                    userId,
                    id,
                    studentName,
                    selectedQuantity,
                    totalPrice.getText().toString(),
                    date,
                    new InsertReservation.ReservationCallback() {
                        @Override
                        public void onSuccess(String message) {
                            Toast.makeText(context, "Reservation successful!", Toast.LENGTH_SHORT).show();
                            finish();
                        }

                        @Override
                        public void onError(String error) {
                            Toast.makeText(context, "Reservation failed: " + error, Toast.LENGTH_LONG).show();
                        }
                    }
            );
        });
    }

    private void updateTotalPrice(String priceStr, int quantity) {
        try {
            double price = Double.parseDouble(priceStr);
            totalPrice.setText(String.format("%.2f", price * quantity));
        } catch (NumberFormatException e) {
            totalPrice.setText("Invalid price");
        }
    }
}
