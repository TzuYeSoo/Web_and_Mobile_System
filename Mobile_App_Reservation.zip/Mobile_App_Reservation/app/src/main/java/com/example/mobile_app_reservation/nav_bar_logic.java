package com.example.mobile_app_reservation;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.widget.ImageButton;

public class nav_bar_logic {
    private static nav_bar_logic _instance;

    public static nav_bar_logic getInstance(){

        if(_instance == null){
            _instance = new nav_bar_logic();
        }
        return  _instance;
    }
    @SuppressLint("MissingInflatedId")
    public void change_activity(Activity activity){

        ImageButton home = activity.findViewById(R.id.nav_home);
        ImageButton reserve = activity.findViewById(R.id.nav_reserve);

        home.setOnClickListener(view -> {
            Intent intent = new Intent(activity, homepage.class);
            activity.startActivity(intent);
        });

        reserve.setOnClickListener(view -> {
            Intent intent = new Intent(activity, Reservation.class);
            activity.startActivity(intent);
        });


    }
}
